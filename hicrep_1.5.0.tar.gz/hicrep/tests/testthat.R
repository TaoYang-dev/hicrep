library(testthat)
library(hicrep)

test_check("hicrep")

#' HiCRep pipeline calculates reproducibility of Hi-C intrachromosome data
#'
#' The pipelne is a two-step method. The first step is to smooth the Hi-C matrix, and the
#' second step is to calculate the stratum-adjusted correlation coefficient (scc). The method also
#' provides the estimation of asymptotic standard deviation of scc.
#'
#' @details
#' \itemize{
#'  \item{Package: }{hicrep}
#'  \item{Type: }{Package}
#'  \item{Version: }{0.1.0}
#'  \item{Date: }{2016-12-5}
#'  \item{License: }{GPL-2}
#'  \item{LazyLoad: }{Yes}
#' }
#'
#' The main functions are \code{\link{prep}}, \code{\link{get.scc}} and \code{\link{htrain}}. The function \code{\link{prep}}
#' will take the two replicates of \eqn{N*(3+N)} matrix format as input, and return the vectorized, smoothed or unsmoothed
#' (when smoothing neighborhood size parameter h = 0) Hi-C data, which will subsequently used to compute stratum-adjusted
#' correlation coefficients (scc). The function \code{\link{get.scc}} computes scc and its asymptotic standard  deviation, and
#' the function \code{\link{htrain}} estimates optimal smoothing neighborhood size from the input matrices.
#' @author
#' Tao Yang
#' Maintainer: Tao Yang <xadmyangt@gmail.com>
#' @references
#' HiCRep: assessing the reproducibility of Hi-C data using a stratum-adjusted correlation coefficient. 
#' Tao Yang, Feipeng Zhang, Galip Gurkan Yardimci, Ross C Hardison, William Stafford Noble, Feng Yue, Qunhua Li. 
#' bioRxiv 101386; doi: https://doi.org/10.1101/101386.
#' @examples
#' data(HiCR1)
#' data(HiCR2)
#'
#' #Estimate the optimial smoothing neighborhood size parameter
#' h_hat <- htrain(HiCR1, HiCR2, 1000000, 5000000, 0:2)
#' h_hat <- 0
#' processed <- prep(HiCR1, HiCR2, 1000000, h_hat, 5000000)
#'
#' scc.out <- get.scc(processed, 1000000, 5000000)
#' scc.out$scc
#' scc.out$std


"_PACKAGE"
